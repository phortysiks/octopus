'''Get the current Octopus Agile electricity prices for Area J'''
import datetime
import requests

API_ENDPOINT = 'https://api.octopus.energy/v1/products/AGILE-FLEX-22-11-25/electricity-tariffs/E-1R-AGILE-FLEX-22-11-25-J/standard-unit-rates/' #pylint: disable=line-too-long
current_price_lookup = requests.get(API_ENDPOINT, timeout=4).json()
current_datetime = datetime.datetime.now().isoformat()
prices_list = current_price_lookup['results']


def get_current_price():
    '''Get the current Octopus Agile electricity prices for Area J'''
    for window in prices_list:
        if (window['valid_from'] < current_datetime) and window['valid_to'] > current_datetime:
            current_price = window['value_inc_vat']
            rounded_price = round(current_price, 1)
            print(f"The current price is {rounded_price}p")

get_current_price()
